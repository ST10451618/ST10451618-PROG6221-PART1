﻿using System;
using System.Speech.Synthesis;
using System.Threading;
using Figgle;

class CyberSecurityChatbot
{
    static SpeechSynthesizer synth = new SpeechSynthesizer();

    static void Main()
    {
        DisplayAsciiArt();

        synth.Volume = 100;
        synth.Rate = 0;

        PrintWithTypingEffect(" Chatbot: Helloooooo! Welcome to the Cybersecurity Awareness Bot.", ConsoleColor.Yellow);
        synth.Speak("Hello! Welcome to the Cybersecurity Awareness Bot. I am here to help you stay safe online.");

        PrintDivider();

        Console.ForegroundColor = ConsoleColor.Green;
        Console.Write(" What's your name buddy? ");
        Console.ResetColor();
        string userName = Console.ReadLine();

        PrintWithTypingEffect($"\n Chatbot: Welcome, {userName}! I'm the Cybersecurity Awareness Bot.", ConsoleColor.Yellow);
        synth.Speak($"Welcome, {userName}! I'm the Cybersecurity Awareness Bot.");
        PrintWithTypingEffect("You can ask me about cybersecurity topics like phishing, password safety, and safe browsing. Don't worry I'll give you examples", ConsoleColor.Yellow);

        PrintDivider();

        while (true)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("\nYou: ");
            Console.ResetColor();
            string input = Console.ReadLine().Trim().ToLower();

            if (string.IsNullOrEmpty(input))
            {
                PrintWithTypingEffect(" Please enter a valid question.", ConsoleColor.Red);
                synth.Speak("Please enter a valid question.");
                continue;
            }
            else if (input == "exit" || input == "quit")
            {
                PrintDivider();
                PrintWithTypingEffect($" Goodbye {userName}, See you soon!!!", ConsoleColor.Green);
                synth.Speak($"Goodbye {userName}, See you soon!");
                break;
            }
            else
            {
                RespondToUser(input);
            }
        }
    }

    static void DisplayAsciiArt()
    {
        string title = "Cybersecurity Awareness Bot";
        string asciiArt = FiggleFonts.Standard.Render(title);
        int width = title.Length + 100;

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("╔" + new string('═', width) + "╗");
        Console.WriteLine($"║           {title}                   ║");// border for the ascii "welcome to Cybersecurity Awareness Chatbot "
        Console.WriteLine("╠" + new string('═', width) + "╣");
        Console.WriteLine(asciiArt);
        Console.WriteLine("╚" + new string('═', width) + "╝");
        Console.ResetColor();
    }

    static void PrintDivider()
    {
        Console.ForegroundColor = ConsoleColor.DarkGray;
        Console.WriteLine("\n──────────────────────────────────────────────\n");// a divider to make space between the chatbot and user responses
        Console.ResetColor();
    }

    static void PrintWithTypingEffect(string message, ConsoleColor color)
    {
        Console.ForegroundColor = color;
        foreach (char c in message)
        {
            Console.Write(c);
            Thread.Sleep(20);
        }
        Console.WriteLine();
        Console.ResetColor();
    }

    static void RespondToUser(string input)
    {
        if (input == "how are you?")
        {
            PrintWithTypingEffect(" Chatbot: I'm here to help you stay safe online!", ConsoleColor.Blue);
            synth.Speak("I'm here to help you stay safe online!");
        }
        else if (input == "what's your purpose?") //dialog
        {
            PrintWithTypingEffect(" Chatbot: My purpose is to provide cybersecurity awareness and help you stay safe online.", ConsoleColor.Yellow);
            synth.Speak("My purpose is to provide cybersecurity awareness and help you stay safe online.");
        }
        else if (input == "what can i ask you about?")
        {
            PrintWithTypingEffect(" Chatbot: You can ask me about phishing, password safety, secure browsing, and general online security.", ConsoleColor.Yellow);
            synth.Speak("You can ask me about phishing, password safety, secure browsing, and general online security.");
        }
        else if (input == "what is phishing?")
        {
            PrintWithTypingEffect(" Chatbot: Phishing is a cyber attack where scammers trick individuals into providing sensitive information like passwords or credit card details.", ConsoleColor.Yellow);
            PrintWithTypingEffect(" Example: A fake email pretending to be from your bank asking for your login credentials.", ConsoleColor.Yellow);
            synth.Speak("Phishing is a cyber attack where scammers trick individuals into providing sensitive information like passwords or credit card details. An example is a fake email pretending to be from your bank asking for your login credentials.");
        }
        else if (input == "what is password safety?")
        {
            PrintWithTypingEffect(" Chatbot: Well, Password safety involves creating strong passwords and keeping them secure from unauthorized access.", ConsoleColor.Yellow);
            PrintWithTypingEffect(" Example: Using a mix of uppercase, lowercase, numbers, and symbols in your password and enabling two-factor authentication.", ConsoleColor.Yellow);
            synth.Speak("Password safety involves creating strong passwords and keeping them secure from unauthorized access. An example is using a mix of uppercase, lowercase, numbers, and symbols in your password and enabling two-factor authentication.");
        }
        else if (input == "what is safe browsing?")
        {
            PrintWithTypingEffect("🛡 Chatbot: Safe browsing means using encrypted connections (HTTPS), avoiding suspicious links, and enabling privacy settings.", ConsoleColor.Yellow);
            PrintWithTypingEffect(" Example: Always check for 'HTTPS' in the URL before entering sensitive data.", ConsoleColor.Yellow);
            synth.Speak("Secure browsing means using encrypted connections, avoiding suspicious links, and enabling privacy settings. Always check for HTTPS in the URL before entering sensitive data.");
        }
        else
        {
            PrintWithTypingEffect(" Chatbot: I'm not sure how to answer that. Try asking about cybersecurity topics.", ConsoleColor.Red);
            synth.Speak("I'm not sure how to answer that. Try asking about cybersecurity topics.");
        }

        PrintDivider();
        PrintWithTypingEffect(" Would you like to ask another question? Type your question or type 'exit' to end the chat.", ConsoleColor.Green);
        synth.Speak("Would you like to ask another question? Type your question or type exit to end the chat.");
    }
}
    